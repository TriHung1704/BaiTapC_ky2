﻿using System;

namespace Struct
{
    class Program
    {
        struct SinhVien{
            public double maso222;
            public string hoten222;
            public double diemtoan222;
            public double diemly222;
            public double diemhoa222;
        }
        static void NhapThongTinSinhVien(out SinhVien SV222)
        {
            Console.Write("Ma So222: ");
            SV222.maso222 = double.Parse(Console.ReadLine());
            Console.Write("Ho Ten222: ");
            SV222.hoten222 = Console.ReadLine();
            Console.Write("Diem Toan222: ");
            SV222.diemtoan222 = double.Parse(Console.ReadLine());
            Console.Write("Diem Ly222: ");
            SV222.diemly222 = double.Parse(Console.ReadLine());
            Console.Write("Diem Hoa222: ");
            SV222.diemhoa222 = double.Parse(Console.ReadLine());

        }
        static void XuatThongTinSinhVien(SinhVien SV222)
        {
            Console.WriteLine("Ma So222: " + SV222.maso222);
            Console.WriteLine("Ho Ten222: " + SV222.hoten222);
            Console.WriteLine("Diem Toan222: " + SV222.diemtoan222);
            Console.WriteLine("Diem Ly222: " + SV222.diemly222);
            Console.WriteLine("Diem Hoa222: " + SV222.diemhoa222);
        }
        static double DiemTB(SinhVien SV222)
        {
            return (SV222.diemtoan222 + SV222.diemly222 + SV222.diemhoa222) / 3;

        }
        static void Main(string[] args)
        {
            SinhVien sv222 = new SinhVien();
            Console.WriteLine("Nhap thongtinsinhvien: ");
            NhapThongTinSinhVien(out sv222);
            Console.WriteLine("#################");
            Console.WriteLine("Thong tin sinh vien vua nhap vao: ");
            XuatThongTinSinhVien(sv222);
            Console.WriteLine("Diem trung binh la: " + DiemTB(sv222));
            Console.ReadLine();
            Console.ReadKey();

        }
    }
}
